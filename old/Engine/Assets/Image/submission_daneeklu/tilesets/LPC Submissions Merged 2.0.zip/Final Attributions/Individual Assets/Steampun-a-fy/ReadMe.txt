All assets made by Anamaris and Krusmira,
Dual-Licensed under GPLv3 and CC BY-SA 3.0