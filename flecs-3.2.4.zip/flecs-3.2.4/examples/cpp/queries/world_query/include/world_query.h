#ifndef WORLD_QUERY_H
#define WORLD_QUERY_H

/* This generated file contains includes for project dependencies */
#include "world_query/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

