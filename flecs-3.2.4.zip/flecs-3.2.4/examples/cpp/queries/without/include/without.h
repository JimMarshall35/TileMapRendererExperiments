#ifndef WITHOUT_H
#define WITHOUT_H

/* This generated file contains includes for project dependencies */
#include "without/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

