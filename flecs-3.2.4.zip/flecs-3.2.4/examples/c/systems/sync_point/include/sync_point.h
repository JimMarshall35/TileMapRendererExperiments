#ifndef SYNC_POINT_H
#define SYNC_POINT_H

/* This generated file contains includes for project dependencies */
#include "sync_point/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

