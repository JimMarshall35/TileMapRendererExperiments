#ifndef DELTA_TIME_H
#define DELTA_TIME_H

/* This generated file contains includes for project dependencies */
#include "delta_time/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

