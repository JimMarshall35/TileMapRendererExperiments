#ifndef CUSTOM_PIPELINE_H
#define CUSTOM_PIPELINE_H

/* This generated file contains includes for project dependencies */
#include "custom_pipeline/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

