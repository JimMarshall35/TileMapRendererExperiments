#ifndef MUTATE_ENTITY_H
#define MUTATE_ENTITY_H

/* This generated file contains includes for project dependencies */
#include "mutate_entity/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

