#ifndef SLOTS_H
#define SLOTS_H

/* This generated file contains includes for project dependencies */
#include "slots/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

