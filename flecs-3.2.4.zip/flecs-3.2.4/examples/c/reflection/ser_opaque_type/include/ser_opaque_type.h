#ifndef SER_OPAQUE_TYPE_H
#define SER_OPAQUE_TYPE_H

/* This generated file contains includes for project dependencies */
#include "ser_opaque_type/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

