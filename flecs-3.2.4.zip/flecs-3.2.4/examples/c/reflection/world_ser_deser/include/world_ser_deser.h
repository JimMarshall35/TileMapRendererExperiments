#ifndef WORLD_SER_DESER_H
#define WORLD_SER_DESER_H

/* This generated file contains includes for project dependencies */
#include "world_ser_deser/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

