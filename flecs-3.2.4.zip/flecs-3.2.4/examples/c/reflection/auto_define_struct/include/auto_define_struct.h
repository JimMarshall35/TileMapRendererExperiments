#ifndef AUTO_DEFINE_STRUCT_H
#define AUTO_DEFINE_STRUCT_H

/* This generated file contains includes for project dependencies */
#include "auto_define_struct/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

