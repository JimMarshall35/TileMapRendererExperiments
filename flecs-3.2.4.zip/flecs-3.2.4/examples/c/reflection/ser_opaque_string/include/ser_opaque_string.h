#ifndef SER_OPAQUE_STRING_H
#define SER_OPAQUE_STRING_H

/* This generated file contains includes for project dependencies */
#include "ser_opaque_string/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

