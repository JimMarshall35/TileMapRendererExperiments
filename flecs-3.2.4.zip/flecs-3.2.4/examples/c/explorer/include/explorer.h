#ifndef EXPLORER_H
#define EXPLORER_H

/* This generated file contains includes for project dependencies */
#include "explorer/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

