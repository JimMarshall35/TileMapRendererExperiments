#ifndef HOOKS_H
#define HOOKS_H

/* This generated file contains includes for project dependencies */
#include "hooks/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

