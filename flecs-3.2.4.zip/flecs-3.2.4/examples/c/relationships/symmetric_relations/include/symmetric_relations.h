#ifndef SYMMETRIC_RELATIONS_H
#define SYMMETRIC_RELATIONS_H

/* This generated file contains includes for project dependencies */
#include "symmetric_relations/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

