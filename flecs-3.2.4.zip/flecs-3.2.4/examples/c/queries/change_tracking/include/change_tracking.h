#ifndef CHANGE_TRACKING_H
#define CHANGE_TRACKING_H

/* This generated file contains includes for project dependencies */
#include "change_tracking/bake_config.h"

#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif

